/* usage.c -- print a small help about me.

   Copyright (C) 1994 Ralph Schleicher  */

/* This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#include <config.h>


void
DEFUN_VOID (usage)
{
  fprintf (stderr,
    "Usage:  faxdvi [-n <number>] [-x <program>] [-V] <dvi-file> ...\n\n"
    "\t-n, --number\n"
    "\t\tOverride FAX number stored in a DVI file.\n"
    "\t-x, --execute\n"
    "\t\tCall <program> for sending the FAX.\n"
    "\t-V, --version\n"
    "\t\tPrint the version number and exit.\n"
    "\t-?, --help\n"
    "\t\tPrint this short help page.\n");
}
