/* getchar.c -- read a single character from a DVI file.

   Copyright (C) 1994 Ralph Schleicher  */

/* This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#include <config.h>
#include "extern.h"


int
DEFUN (get_char, (mode),
int mode)
{
  int result;

  result = fgetc (dvi_file);
  if (result == EOF && mode == CHECK)
    die ("%s:%s: Read error at position %d\n", prog_name, dvi_name, dvi_pos);

  ++dvi_pos;

  return (result);
}
