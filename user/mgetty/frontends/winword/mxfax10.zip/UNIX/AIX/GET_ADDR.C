/*
  Small c-program to get the mailaddress for the report. Informations about 
  the used functions could be find in the Info Explorer. Keyword: "libqb".
  Compiled with "cc get_address.c -lqb -o get_address".

   02.10.95 Markus Freidhof
*/

#include <stdio.h>

int main(int argc, char *argv[])

{

  log_init();                         /* Initialize the status file interface */

  printf ("%s",get_to());                 /* Print mailaddress for the report */

}  
